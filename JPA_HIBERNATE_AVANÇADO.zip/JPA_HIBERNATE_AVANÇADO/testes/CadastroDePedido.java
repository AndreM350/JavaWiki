package JPA_HIBERNATE_AVANÇADO.testes;

import JPA_HIBERNATE_AVANÇADO.DAO.CategoriaDAO;
import JPA_HIBERNATE_AVANÇADO.DAO.ClienteDAO;
import JPA_HIBERNATE_AVANÇADO.DAO.PedidoDAO;
import JPA_HIBERNATE_AVANÇADO.DAO.ProdutoDAO;
import JPA_HIBERNATE_AVANÇADO.VO.RelatorioDeVendasVo;
import JPA_HIBERNATE_AVANÇADO.modelo.*;
import JPA_HIBERNATE_AVANÇADO.util.JPAUtil;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;

public class CadastroDePedido {
    public static void main(String[] args) {

        //popular o db cadastrando produtos e categorias
        popularBancoDeDados();

        //recuperar o produto do DB
        EntityManager em = JPAUtil.getEntityManager();

        ProdutoDAO produtoDAO = new ProdutoDAO(em);
        ClienteDAO clienteDAO = new ClienteDAO(em);


        Produto produto = produtoDAO.buscarPorId(1l);
        Produto produto2 = produtoDAO.buscarPorId(2l);
        Produto produto3 = produtoDAO.buscarPorId(3l);

        Cliente cliente = clienteDAO.buscarPorId(1l);

        em.getTransaction().begin(); //inicia a transação


        //criação do pedido ------------- 1
        Pedido pedido = new Pedido(cliente);

        //adicionando item ao pedido 1
        pedido.adicionarItem(new ItemPedido(10,pedido,produto));
        pedido.adicionarItem(new ItemPedido(40,pedido,produto2));

        //criação do pedido ------------- 2
        Pedido pedido2 = new Pedido(cliente);

        //adicionando item ao pedido 2
        pedido.adicionarItem(new ItemPedido(2,pedido,produto3));





        PedidoDAO pedidoDAO = new PedidoDAO(em);
        pedidoDAO.cadastrar(pedido);
        pedidoDAO.cadastrar(pedido2);


        em.getTransaction().commit(); //finaliza a transação

        BigDecimal totalVendido = pedidoDAO.valorTotalVendido();
        System.out.println("Valor total vendido: "+ totalVendido);

        List<Object[]> relatorio = pedidoDAO.relatorioDeVendas();
        for (Object[] obj: relatorio) {
            System.out.println(obj[0]); //Galaxy Note 10 Plus
            System.out.println(obj[1]); //10
            System.out.println(obj[2]); //2022-02-18
        }

        //Utilizando o VO
        List<RelatorioDeVendasVo> relatorioDeVendasVos = pedidoDAO.relatorioDeVendasVO();
        relatorioDeVendasVos.forEach(System.out::println);



    }



    //reaproveitando o método
    private static void popularBancoDeDados() {
        Categoria celulares = new Categoria("CELULARES");
        Categoria videogames = new Categoria("VIDEOGAMES");
        Categoria informatica = new Categoria("INFORMATICA");

        Produto celular = new Produto("Galaxy Note 10 Plus","Celular com caneta da Samsung",new BigDecimal("3500"), celulares);
        Produto videogame = new Produto("PS5","PlayStation 5 1TB",new BigDecimal("5800"), celulares);
        Produto macbook = new Produto("Macbook","MacBook Pro M1",new BigDecimal("9500"), celulares);

        //criação do cliente
        Cliente cliente = new Cliente("Andre","02076931295");

        //Passando como parâmetro um EntityManager que faz o acesso ao DB
        EntityManager em = JPAUtil.getEntityManager();
        ProdutoDAO produtoDAO = new ProdutoDAO(em);
        CategoriaDAO categoriaDAO = new CategoriaDAO(em);
        ClienteDAO clienteDAO = new ClienteDAO(em);

        em.getTransaction().begin(); //inicia a transação

        //Método abaixo era utilizado antes da classe ProdutoDAO
        //em.persist(celular); //método para inserir no DB, pelo mapeamento da entidade a JPA saberá em qual tabela inserir este objeto.

        //Para não ter erro de inserção a tabela de categorias precisará estar criada antes de tentar inserir o produto vinculado com a categoria.
        categoriaDAO.cadastrar(celulares);
        categoriaDAO.cadastrar(videogames);
        categoriaDAO.cadastrar(informatica);

        //Linhas 29 e 33 tem o mesmo funcionamento basicamente...
        //Com a classe ProdutoDAO utilizamos o método criado lá
        produtoDAO.cadastrar(celular);
        produtoDAO.cadastrar(videogame);
        produtoDAO.cadastrar(macbook);

        clienteDAO.cadastrar(cliente);
        em.getTransaction().commit();  //validar
        em.close(); //fechando o recurso
    }
}
