package JPA_HIBERNATE_AVANÇADO.DAO;

import JPA_HIBERNATE_AVANÇADO.modelo.Pedido;
import JPA_HIBERNATE_AVANÇADO.VO.RelatorioDeVendasVo;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;

public class PedidoDAO {

    private EntityManager em;

    //injeção de dependência - quem for instanciar uma classe DAO vai ter que passar um EntityManager
    public PedidoDAO(EntityManager em) {
        this.em = em;
    }

    public void cadastrar (Pedido pedido){
        this.em.persist(pedido);
    }

    public BigDecimal valorTotalVendido(){
        String jpql = "SELECT SUM(p.valorTotal) FROM Pedido p";
        return em.createQuery(jpql, BigDecimal.class)
                .getSingleResult();
    }

    //------------------------------------- atentar pros espaços da concatenação na ," --------------------------------------

    public List<Object[]> relatorioDeVendas(){
        String jpql = "SELECT produto.nome, " +
                "SUM(item.quantidade), " +
                "MAX(pedido.data) " +
                "FROM Pedido pedido " +
                "JOIN pedido.itens item " +
                "JOIN item.produto produto " +
                "GROUP BY produto.nome " +
                "ORDER BY item.quantidade DESC ";
        return em.createQuery(jpql,Object[].class).getResultList();
        //array de objects, pois cada coluna retorna um objeto de um tipo diferente

    }

    //retornando como uma lista de objetos do tipo RelatorioDeVendasVO
    public List<RelatorioDeVendasVo> relatorioDeVendasVO(){
        String jpql = "SELECT new JPA_HIBERNATE_AVANÇADO.VO.RelatorioDeVendasVo("
                + "produto.nome, "
                + "SUM(item.quantidade), "
                + "MAX(pedido.data)) "
                + "FROM Pedido pedido "
                + "JOIN pedido.itens item "
                + "JOIN item.produto produto "
                + "GROUP BY produto.nome "
                + "ORDER BY item.quantidade DESC ";
        return em.createQuery(jpql,RelatorioDeVendasVo.class).getResultList();
        //array de RelatorioDeVendasVO, onde cada coluna retorna um atributo

    }




}
