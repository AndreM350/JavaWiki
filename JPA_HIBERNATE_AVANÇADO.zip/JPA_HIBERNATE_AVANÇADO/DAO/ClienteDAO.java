package JPA_HIBERNATE_AVANÇADO.DAO;

import JPA_HIBERNATE_AVANÇADO.modelo.Cliente;
import JPA_HIBERNATE_AVANÇADO.modelo.Pedido;
import JPA_HIBERNATE_AVANÇADO.modelo.Produto;

import javax.persistence.EntityManager;

public class ClienteDAO {

    private EntityManager em;

    //injeção de dependência - quem for instanciar uma classe DAO vai ter que passar um EntityManager
    public ClienteDAO(EntityManager em) {
        this.em = em;
    }

    public void cadastrar (Cliente cliente){
        this.em.persist(cliente);
    }

    public Cliente buscarPorId(Long id){
        return em.find(Cliente.class, id);
    }



}
