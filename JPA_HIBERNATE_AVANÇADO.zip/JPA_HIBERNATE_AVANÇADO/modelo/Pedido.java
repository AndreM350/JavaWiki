package JPA_HIBERNATE_AVANÇADO.modelo;


import org.hibernate.annotations.Comment;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="pedidos")
public class Pedido {

    @Id //<<<<<<<<< Anotação de vínculo de chave primária
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Valor_total")
    private BigDecimal valorTotal = BigDecimal.ZERO;
    private LocalDate data = LocalDate.now();

    @ManyToOne
    private Cliente cliente;

    //Aqui é um relacionamento bidirecional e precisamos indicar para a JPA, caso contrário ela irá gerar uma nova tabela.
    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL) //indicar na string o atributo que faz a outra ponta do relacionamento da tabela
    //cascada é pra refletir tudo que é alterado em pedido também alterar na tabela item_pedido
    private List<ItemPedido> itens = new ArrayList<>();
    //é sempre interessante já inicializar as listas via >> new ArrayList<>()

    //método para adicionar itens no pedido
    public void adicionarItem(ItemPedido item){
        item.setPedido(this); //item conhece o pedido
        this.itens.add(item); //pedido conhece o item
        this.valorTotal = this.valorTotal.add(item.getValor());
    }




    public Pedido() { //construtor padrão que a JPA necessita
    }

    //GETTER E SETTERS ----------------------------------------

    public Pedido(Cliente cliente) {
        this.cliente = cliente;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
