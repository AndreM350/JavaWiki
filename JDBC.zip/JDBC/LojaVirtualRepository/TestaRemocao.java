package JDBC.LojaVirtualRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestaRemocao {
    public static void main(String[] args) throws SQLException {

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection con = connectionFactory.recuperarConexao();

        PreparedStatement stm = con.prepareStatement("DELETE FROM PRODUTO WHERE ID > ?");
        stm.setInt(1,2);

        //Statement stm = con.createStatement();
        stm.execute();

        Integer linhaModificadas = stm.getUpdateCount(); //retorna quantas linhas foram modificadas após a execução do statement
        System.out.println("Linhas modificadas: " + linhaModificadas);


    }
}
