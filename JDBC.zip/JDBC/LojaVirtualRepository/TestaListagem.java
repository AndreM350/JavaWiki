package JDBC.LojaVirtualRepository;

import java.sql.*;

public class TestaListagem {
    public static void main(String[] args) throws SQLException {
        //url,user,senha
        //método antigo sem a classe que cria a conexão
        //Connection con = DriverManager.getConnection("jdbc:mysql://localhost/loja_virtual?useTimezone=true&serverTimezone=UTC", "root", "dbroot");

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection con = connectionFactory.recuperarConexao();

        System.out.println("Fechando a conexão.");

        //Statement stm = con.createStatement();
        //boolean resultado = stm.execute("SELECT ID, NOME, DESCRICAO FROM PRODUTO"); //retorna true se for uma lista


        PreparedStatement stm = con.prepareStatement("SELECT ID, NOME, DESCRICAO FROM PRODUTO");
        stm.execute();
        ResultSet rst = stm.getResultSet();

        //printar valores enquanto existirem próximos valores
        while(rst.next())  {
            Integer id = rst.getInt("id");
            System.out.println(id);
            String nome = rst.getString("nome");
            System.out.println(nome);
            String desc = rst.getString("descricao");
            System.out.println(desc);

        }







        con.close();

    }

}
