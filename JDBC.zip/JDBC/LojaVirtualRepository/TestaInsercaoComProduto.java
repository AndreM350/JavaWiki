package JDBC.LojaVirtualRepository;

import JDBC.LojaVirtualRepository.dao.ProdutoLojaVirtualDAO;
import JDBC.LojaVirtualRepository.modelo.Produto;

import java.sql.*;
import java.util.List;

public class TestaInsercaoComProduto {
    public static void main(String[] args) throws SQLException {

        Produto comoda = new Produto("Cômoda", "Cômoda vertical");

        try(Connection connection = new ConnectionFactory().recuperarConexao()){
            ProdutoLojaVirtualDAO produtoLojaVirtualDAO = new ProdutoLojaVirtualDAO(connection);
            produtoLojaVirtualDAO.salvar(comoda);
            List<Produto> listaDeProdutos = produtoLojaVirtualDAO.listar();
            listaDeProdutos.stream().forEach(lp -> System.out.println(lp));
        }


    }
}
