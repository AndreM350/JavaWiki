package JDBC.LojaVirtualRepository;

import java.sql.Connection;
import java.sql.SQLException;

public class TestaConexão {
    public static void main(String[] args) throws SQLException {

        //url,user,senha
        //método antigo sem a classe que cria a conexão
        //Connection con = DriverManager.getConnection("jdbc:mysql://localhost/loja_virtual?useTimezone=true&serverTimezone=UTC", "root", "dbroot");

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection con = connectionFactory.recuperarConexao();

        System.out.println("Fechando a conexão!");
        con.close();

    }
}
