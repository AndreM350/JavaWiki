package JDBC.LojaVirtualRepository;

import java.sql.SQLException;

public class TestaPoolConexoes {
    public static void main(String[] args) throws SQLException {
        
        ConnectionFactory connectionFactory = new ConnectionFactory();

        for (int i = 0; i < 20; i++) { //simulando 20 conexões
            connectionFactory.recuperarConexao();
            System.out.println("Conexão de número: " + i);
        }
        
    }
}
